import 'package:flutter/material.dart';

class TopView extends StatelessWidget {
  final double sfMin;
  const TopView({super.key, required this.sfMin});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final height = constraints.maxHeight;
        return Stack(
          alignment: Alignment.center,
          children: [
            MainImage(sfMin: sfMin),
            Positioned(
              top: height*0.5-775*sfMin,    
              right: 1800*sfMin,   
              child: BaseInfo(sfMin: sfMin)
            ),
          ],
        );
      },
    );
  }
}

class ButtonRow extends StatelessWidget {
  final double sfMin;
  const ButtonRow({super.key, required this.sfMin});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        TextButton(
          onPressed: () {
            // Your action here
          },
          child: SizedBox(
            width: 500.0 * sfMin,
            height: 110.0 * sfMin,
            child: Image.asset("assets/frame0/names.png"),
          ),
        ),
        IconButton(
          onPressed: () {

          },
          icon:
            SizedBox(
              width: 500*sfMin,
              height: 110*sfMin,
              child: Image.asset("assets/frame0/history.png"),
              )
        ),
      ],
    );
  }
}

class MainImage extends StatelessWidget {
  final double sfMin;
  const MainImage({super.key, required this.sfMin});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Spacer(),
        Row(
          children: [
            SizedBox(
              width: 440*sfMin,
              height: 1750*sfMin,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Expanded(flex: 2, child: SizedBox()),
                  TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom(padding: EdgeInsets.zero),
                    child: SizedBox(
                      width: 440*sfMin,
                      height: 170*sfMin,
                      child: Image.asset("assets/frame0/mainPool.png"),
                    )
                  ),
                  const Expanded(flex: 1, child: SizedBox()),
                  TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom(padding: EdgeInsets.zero),
                    child: SizedBox(
                      width: 410*sfMin,
                      height: 160*sfMin,
                      child: Image.asset("assets/frame0/otherPool.png"),
                    )
                  ),
                  const Expanded(flex: 10, child: SizedBox(),)
                ],
              ),
            ),
            const Spacer(),
            SizedBox(
              width: 2550.0*sfMin,
              height: 1750.0*sfMin,
              child: Image.asset("assets/frame0/mainPic.png")
            )
          ]
        ),
        const Spacer()
      ],
    );
  }
}

class BaseInfo extends StatelessWidget {
  final double sfMin;
  const BaseInfo({super.key, required this.sfMin});

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.topLeft,
      children: [
        SizedBox(
          width: 1150*sfMin,
          height: 1750*sfMin,
          child: Row(
            children: [
              const Spacer(),
              SizedBox(
                width: 800*sfMin,
                height: 1710*sfMin,
                child: Image.asset("assets/frame0/base.png")
              ),
              const Spacer()
            ],
          )
        ),
        Positioned( //label
          top:70.0*sfMin,
          left: 100*sfMin,
          child: SizedBox(
            width: 360*sfMin,
            height: 80*sfMin,
            child: Image.asset("assets/frame0/label.png"),
          ),
        ),
        Positioned( //infos
          top: 150*sfMin,
          left: 200*sfMin,
          child: SizedBox(
            width: 700*sfMin,
            height: 1610*sfMin,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "普二忠",
                  style: TextStyle(
                    fontSize: 128*sfMin,
                    fontWeight: FontWeight.w800
                  ),
                  ),
                const Expanded(flex: 1, child: SizedBox()),
                SizedBox(
                  width: 310*sfMin,
                  height: 75*sfMin,
                  child: Image.asset("assets/frame0/timeLeft.png"),
                ),
                const Expanded(flex: 1, child: SizedBox()),
                Text(
                  "每10次抽卡必出四星以上對象",
                  style: TextStyle(
                    fontSize: 48*sfMin,
                    fontWeight: FontWeight.w700
                  ),
                ),
                const Expanded(flex: 1, child: SizedBox()),
                Text(
                  "公平機率，公平遊戲",
                  style: TextStyle(
                    fontSize: 48*sfMin,
                    fontWeight: FontWeight.w700
                  ),
                ),
                const Expanded(flex: 8, child: SizedBox()),
                SizedBox(
                  width: 1150*sfMin,
                  height: 510*sfMin,
                  child: Row(
                    children: [
                      const Spacer(),
                      const Spacer(),
                      SizedBox(
                        width: 600*sfMin,
                        height: 510*sfMin,
                        child: Row(
                          children: [
                            SizedBox(
                              width: 180*sfMin,
                              height: 510*sfMin,
                              child: Image.asset("assets/frame0/4starUp.png"),
                            ),
                            const Spacer(),
                            SizedBox(
                              width: 180*sfMin,
                              height: 510*sfMin,
                              child: Image.asset("assets/frame0/4starUp.png"),
                            ),
                            const Spacer(),
                            SizedBox(
                              width: 180*sfMin,
                              height: 510*sfMin,
                              child: Image.asset("assets/frame0/4starUp.png"),
                            )
                          ],
                        ),
                      ),
                      const Spacer(),
                    ],
                  ),
                ),
                const Expanded(flex: 12, child: SizedBox()),
              ],
            ),
          )
        ),
        Positioned(
          bottom: 0,
          right: 0,
          child: ButtonRow(sfMin: sfMin)
        )
      ],
    );
  }
}

