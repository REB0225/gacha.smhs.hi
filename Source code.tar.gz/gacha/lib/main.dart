import 'dart:math';

import 'package:flutter/material.dart';
import 'top_view.dart';
import 'play_video.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    var sfw = screenWidth/3456;//scale factor
    var sfh = screenHeight/2160;
    var sfMin = min(sfw, sfh);
    

    return MaterialApp(
      home: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/frame0/BGPic.png"),
              fit: BoxFit.cover, 
            ),
          ),
          child: Center(
            child: Stack(
              children: [
                TopView(sfMin: sfMin),
                Positioned(
                  top: 50*sfMin,
                  left: 70*sfMin,
                  child: TopLeftTitle(sfMin: sfMin)
                  ),
                Positioned(
                  bottom: 100*sfMin ,
                  right: 100*sfMin,
                  child:  
                    DrawButton(sfMin: sfMin,
                              width: 700,
                              height: 155,
                              buttonImgPath: "assets/frame0/draw.png",
                            ),

                ),
                Positioned(
                  top: 75*sfMin,
                  right: 60*sfMin,
                  child:CardDistance(sfMin: sfMin)
                ),
                Positioned(
                  bottom: 100*sfMin,
                  left: 100*sfMin,
                  child: SizedBox(
                    width: 235*sfMin,
                    height: 255*sfMin,
                    child: TextButton(
                      onPressed: () {
                        
                      },
                      child: Image.asset("assets/frame0/maintenance.png")
                      ),
                  ))
              ],
            )
          ),
        ),
      ),
    );
  }
}

class TopLeftTitle extends StatelessWidget {
  final double sfMin;
  const TopLeftTitle({super.key, required this.sfMin});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 170*sfMin,
          height: 180*sfMin,
          child: Image.asset("assets/frame0/serviam.png"),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "海星",
              style: TextStyle(
                fontSize: 48*sfMin,
                fontWeight: FontWeight.w800,
                color:const Color(0xFFF2E0B4)
              ),
            ),
            Text(
              "學生抽卡",
              style: TextStyle(
                fontSize: 48*sfMin,
                fontWeight: FontWeight.w800,
                color:const Color(0xFFFFFBFB)
              ),
            ),
          ],
        )
      ],
    );
  }
}

class CardDistance extends StatelessWidget {
  final double sfMin; 
  const CardDistance({super.key, required this.sfMin});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        RichText(//距離四星保底還有
          text: TextSpan(
            children: [
              TextSpan(
                text: "距離",
                style: TextStyle(
                  fontSize: 48*sfMin,
                  fontWeight: FontWeight.w600,
                  color: Colors.white
                ),
              ),
              TextSpan(
                text: "四",
                style: TextStyle(
                  fontSize: 48*sfMin,
                  fontWeight: FontWeight.w600,
                  color: const Color(0xFFCB71FF)
                ),
              ),
              TextSpan(
                text: "星保底還有",
                style: TextStyle(
                  fontSize: 48*sfMin,
                  fontWeight: FontWeight.w600,
                  color: Colors.white
                ),
              )
            ],
          ),
        ),
        Stack(
          alignment: Alignment.center,
          children: [
            SizedBox(
              width: 110*sfMin,
              height: 60*sfMin,
              child: Image.asset("assets/frame0/underNumber.png"),
            ),
            Text(
              "10抽",
              style: TextStyle(
                fontSize: 36*sfMin,
                fontWeight: FontWeight.w500,
                color: const Color(0xFFE8872F)
              ),
            )
          ],
        ),
        RichText(//距離五星保底還有
          text: TextSpan(
            children: [
              TextSpan(
                text: "距離",
                style: TextStyle(
                  fontSize: 48*sfMin,
                  fontWeight: FontWeight.w600,
                  color: Colors.white
                ),
              ),
              TextSpan(
                text: "五",
                style: TextStyle(
                  fontSize: 48*sfMin,
                  fontWeight: FontWeight.w600,
                  color: const Color(0xFFFFAD62)
                ),
              ),
              TextSpan(
                text: "星保底還有",
                style: TextStyle(
                  fontSize: 48*sfMin,
                  fontWeight: FontWeight.w600,
                  color: Colors.white
                ),
              )
            ],
          ),
        ),
        Stack(
          alignment: Alignment.center,
          children: [
            SizedBox(
              width: 110*sfMin,
              height: 60*sfMin,
              child: Image.asset("assets/frame0/underNumber.png"),
            ),
            Text(
              "90抽",
              style: TextStyle(
                fontSize: 36*sfMin,
                fontWeight: FontWeight.w500,
                color: const Color(0xFFE8872F)
              ),
            )
          ],
        ),
      ],
    );
  }
}