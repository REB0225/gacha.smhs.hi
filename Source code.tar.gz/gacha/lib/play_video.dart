import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'package:audioplayers/audioplayers.dart';
import 'dart:async';

class Student{
  final String name;
  final int num;

  Student({required this.name, required this.num});
}

List<Student> students = [
  Student(name: "王永信", num: 1),
  Student(name: "吳星儒", num: 2),
  Student(name: "李少夫", num: 3),
  Student(name: "李羿呈", num: 4),
  Student(name: "林士庭", num: 5),
  Student(name: "林奕辰", num: 6),
  Student(name: "徐來慶", num: 7),
  Student(name: "張丞均", num: 8),
  Student(name: "陳治宇", num: 9),
  Student(name: "陳品銓", num: 10),
  Student(name: "陳訢", num: 11),
  Student(name: "謝暐翰", num: 12),
  Student(name: "黃子彥", num: 13),
  Student(name: "劉恩睿", num: 14),
  Student(name: "潘信庭", num: 15),
  Student(name: "鄭琪諾", num: 16),
  Student(name: "盧顥仁", num: 17),
  Student(name: "謝承佑", num: 18),
  Student(name: "羅允謙", num: 19),
  Student(name: "羅睿竹", num: 20),
  Student(name: "朱莉蓁", num: 21),
  Student(name: "呂安", num: 22),
  Student(name: "林姮瑋", num: 23),
  Student(name: "張宸𬓲", num: 24),
  Student(name: "郭蕎菱", num: 26),
  Student(name: "陳奕妡", num: 27),
  Student(name: "趙珮岑", num: 28),
  Student(name: "賴家安", num: 29),
  Student(name: "陸允樂", num: 31),
];

class DrawButton extends StatefulWidget {
  final String buttonImgPath;
  final double width;
  final double height;
  final double sfMin;
  const DrawButton({super.key, 
                  required this.buttonImgPath,
                  required this.width,
                  required this.height,
                  required this.sfMin
                  });
  @override
  VideoPlayerScreenState createState() => VideoPlayerScreenState();
}

class VideoPlayerScreenState extends State<DrawButton> with SingleTickerProviderStateMixin {
  final AudioPlayer _audioPlayer = AudioPlayer();
  late VideoPlayerController _controller0;
  late VideoPlayerController _controller1;
  late VideoPlayerController _controller2;
  late VideoPlayerController _controllerCard;
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  late Animation<Offset> _offsetAnimationTop;
  late Animation<Offset> _offsetAnimationBottom;
  late Animation<double> _rotationAnimation;
  late Animation<double> _opacityAnimation;
  var animationCount = 0;
  OverlayEntry? _overlayEntry;
  OverlayEntry? _overlayEntryCard;
  bool _isExitButtonVisible = false;
  bool _isMouseVisible = true;
  Timer? _mouseTimer;

  
  int videoNumber = Random().nextInt(3);
  int cardNumber = Random().nextInt(29);

  @override
  void initState() {
    super.initState();
    _initializeVideoPlayer();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1500), // Duration of the animation
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: (10.0),
      end: (2.0),
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.fastEaseInToSlowEaseOut,
    ));

    _offsetAnimationTop = Tween<Offset>(
      begin: const Offset (-0.5, -0.2),
      end: const Offset (-0.04, -0.02),
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.fastEaseInToSlowEaseOut,
    ));

    _offsetAnimationBottom = Tween<Offset>(
      begin: const Offset (0.5, 0.2),
      end: const Offset (0.04, 0.02),
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.fastEaseInToSlowEaseOut,
    ));

    _rotationAnimation = Tween<double>(
      begin: (0.0125),
      end: (0.0125),
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.fastEaseInToSlowEaseOut,
    ));

    _opacityAnimation = Tween<double>(
      begin: (0.0),
      end: (1.0),
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: const Interval(
        0.67, 
        1.0,
        curve: Curves.fastEaseInToSlowEaseOut, 
      ),
    ));

  }

  void _initializeVideoPlayer() {
    _controller0 = VideoPlayerController.asset(
      "assets/frame0/gacha5star.mp4"
    )..initialize().then((_) {
        setState(() {});
      });
    _controller1 = VideoPlayerController.asset(
      "assets/frame0/gacha4star.mp4"
    )..initialize().then((_) {
        setState(() {});
      });
    _controller2 = VideoPlayerController.asset(
      "assets/frame0/gacha3star.mp4"
    )..initialize().then((_) {
        setState(() {});
      });
    _controllerCard = VideoPlayerController.asset(
      "assets/frame0/lightcone.mp4"
    )..initialize().then((_) {
        setState(() {});
      });

    _controller0.addListener(() {
      if (_controller0.value.position == _controller0.value.duration) {
        _showCard(); // Hide the video when it finishes
      }
    });
    _controller1.addListener(() {
      if (_controller1.value.position == _controller1.value.duration) {
        _showCard(); // Hide the video when it finishes
      }
    });
    _controller2.addListener(() {
      if (_controller2.value.position == _controller2.value.duration) {
        _showCard(); // Hide the video when it finishes
      }
    });
    _controllerCard.addListener(() {
      if (_controllerCard.value.isPlaying && !_animationController.isAnimating && animationCount == 0) {
        _animationController.forward(from: 0.0);
        animationCount = 1;
      }

    });
  }

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: () {
        Future.delayed(const Duration(seconds: 1), () {
          _audioPlayer.stop();
        });
        videoNumber = Random().nextInt(3);
        cardNumber = Random().nextInt(29);
        if (videoNumber == 0) {
          _showFullscreenVideo0();
        } else if (videoNumber == 1) {
          _showFullscreenVideo1();
        } else if (videoNumber == 2) {
          _showFullscreenVideo2();
        }
      },
      child: SizedBox(
        width: widget.width * widget.sfMin,
        height: widget.height * widget.sfMin,
        child: Image.asset(widget.buttonImgPath),
      ),
    );
  }

  // Show video in fullscreen mode
  void _showFullscreenVideo0() async {
    await _controller0.seekTo(Duration.zero);
    await _controller0.play();

    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

    if (!mounted) return;

    _overlayEntry = _createOverlayEntry0();

    if (mounted) {
      Overlay.of(context).insert(_overlayEntry!);
      _hideMouse();
    }
  }

  void _showFullscreenVideo1() async {
    await _controller1.seekTo(Duration.zero);
    await _controller1.play();

    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

    if (!mounted) return;

    _overlayEntry = _createOverlayEntry1();

    if (mounted) {
      Overlay.of(context).insert(_overlayEntry!);
      _hideMouse();
    }
  }

  void _showFullscreenVideo2() async {
    await _controller2.seekTo(Duration.zero);
    await _controller2.play();

    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

    if (!mounted) return;

    _overlayEntry = _createOverlayEntry2();

    if (mounted) {
      Overlay.of(context).insert(_overlayEntry!);
      _hideMouse();
    }
  }

  void _showFullscreenVideoCard() async {
    await _controllerCard.seekTo(Duration.zero);
    await _controllerCard.play();

    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

    if (!mounted) return;

    _overlayEntryCard = _createOverlayEntryCard();

    if (mounted) {
      Overlay.of(context).insert(_overlayEntryCard!);
      _hideMouse();
    }
  }

  // Create overlay for fullscreen video
  OverlayEntry _createOverlayEntry0() {
    return OverlayEntry(
      builder: (context) => Positioned.fill(
        child: Material(
          color: Colors.transparent,
          child: MouseRegion(
            cursor: _isMouseVisible ? SystemMouseCursors.basic : SystemMouseCursors.none,
            onHover: (_) => _showMouse(),
            child: GestureDetector(
              onTap: () => _toggleExitButton(),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _controller0.value.size.width,//A
                      height: _controller0.value.size.height,//A
                      child: VideoPlayer(_controller0),//A
                    ),
                  ),
                  if (_isExitButtonVisible)
                    Positioned(
                      top: 50,
                      right: 50,
                      child: IconButton(
                        icon: const Icon(Icons.close, color: Colors.white),
                        onPressed: _showCard,
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  OverlayEntry _createOverlayEntry1() {
    return OverlayEntry(
      builder: (context) => Positioned.fill(
        child: Material(
          color: Colors.transparent,
          child: MouseRegion(
            cursor: _isMouseVisible ? SystemMouseCursors.basic : SystemMouseCursors.none,
            onHover: (_) => _showMouse(),
            child: GestureDetector(
              onTap: () => _toggleExitButton(),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _controller1.value.size.width,//A
                      height: _controller1.value.size.height,//A
                      child: VideoPlayer(_controller1),//A
                    ),
                  ),
                  if (_isExitButtonVisible)
                    Positioned(
                      top: 50,
                      right: 50,
                      child: IconButton(
                        icon: const Icon(Icons.close, color: Colors.white),
                        onPressed: _showCard,
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  OverlayEntry _createOverlayEntry2() {
    return OverlayEntry(
      builder: (context) => Positioned.fill(
        child: Material(
          color: Colors.transparent,
          child: MouseRegion(
            cursor: _isMouseVisible ? SystemMouseCursors.basic : SystemMouseCursors.none,
            onHover: (_) => _showMouse(),
            child: GestureDetector(
              onTap: () => _toggleExitButton(),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _controller2.value.size.width,//A
                      height: _controller2.value.size.height,//A
                      child: VideoPlayer(_controller2),//A
                    ),
                  ),
                  if (_isExitButtonVisible)
                    Positioned(
                      top: 50,
                      right: 50,
                      child: IconButton(
                        icon: const Icon(Icons.close, color: Colors.white),
                        onPressed: () {
                          _showCard();
                          }
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  OverlayEntry _createOverlayEntryCard() {
    return OverlayEntry(
      builder: (context) => Positioned.fill(
        child: Material(
          color: Colors.transparent,
          child: GestureDetector(
            onTap: () async {
              if (_controllerCard.value.position >= _controllerCard.value.duration- const Duration(milliseconds: 1100)) {
                _exitOverlay();
              }else {
                final videoDuration = _controllerCard.value.duration;
                await _controllerCard.seekTo(videoDuration - const Duration(seconds: 1));
              }
            },
            child: Stack(
              fit: StackFit.expand,
              children: [
                FittedBox(
                  fit: BoxFit.cover,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: _controllerCard.value.size.width,//A
                        height: _controllerCard.value.size.height,//A
                        child: VideoPlayer(_controllerCard),//A
                      ),
                      ScaleTransition(//top
                        scale: _scaleAnimation,
                        child: RotationTransition(
                          turns: _rotationAnimation,
                          child: SlideTransition(
                            position: _offsetAnimationBottom,
                            child: Image.asset('assets/frame0/lightconeBack.png', width: 450*widget.sfMin, height: 1500*widget.sfMin),
                          ),
                        ),
                      ),
                      ScaleTransition(//middle
                        scale: _scaleAnimation,
                        child: RotationTransition(
                          turns: _rotationAnimation,  
                          child: Stack(
                            children: [
                              Image.asset(
                                "assets/cards/${_returnCard(cardNumber).num}l.png",
                                errorBuilder: (context, error, stackTrace) {
                                  return Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Image.asset("assets/cards/nulll.png", width: 450*widget.sfMin, height: 1500*widget.sfMin),
                                      Text(_returnCard(cardNumber).name,
                                        style: TextStyle(
                                          fontSize: 48*widget.sfMin,
                                          fontWeight: FontWeight.w800,
                                          color:const Color(0xFFFFFFFF)
                                        ),
                                      )
                                    ],
                                  );
                                },
                                width: 450*widget.sfMin,
                                height: 1500*widget.sfMin
                              ),
                              Image.asset("assets/frame0/lightconeTopper.png", width: 450*widget.sfMin, height: 1500*widget.sfMin),
                            ],
                          ),
                        )
                      ),
                      ScaleTransition(//top
                        scale: _scaleAnimation,
                        child: RotationTransition(
                          turns: _rotationAnimation,
                          child: SlideTransition(
                            position: _offsetAnimationTop,
                            child: Image.asset('assets/frame0/lightconeFront.png', width: 450*widget.sfMin, height: 1500*widget.sfMin),
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 750*widget.sfMin,
                        left: 1000*widget.sfMin,
                        child: FadeTransition(
                          opacity: _opacityAnimation,
                          child: SizedBox(
                            width: 400,
                            height: 100,
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Image.asset("assets/cards/nametag.png"),
                                Text(_returnCard(cardNumber).name,
                                  style: TextStyle(
                                    fontSize: 128*widget.sfMin,
                                    fontWeight: FontWeight.w800,
                                    color:const Color(0xFFFFFFFF)
                                  ),
                                )
                              ],
                            )
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Show the mouse cursor
  void _showMouse() {
    if (!_isMouseVisible) {
      setState(() {
        _isMouseVisible = true;
        _overlayEntry?.markNeedsBuild();  // Rebuild overlay to update cursor
      });
    }
    _mouseTimer?.cancel();
    _mouseTimer = Timer(const Duration(seconds: 3), _hideMouse);
  }

  // Hide the mouse cursor
  void _hideMouse() {
    if (mounted && _isMouseVisible) {
      setState(() {
        _isMouseVisible = false;
        _overlayEntry?.markNeedsBuild();  // Rebuild overlay to hide cursor
      });
    }
  }

  // Toggle the visibility of the exit button
  void _toggleExitButton() {
    setState(() {
      _isExitButtonVisible = !_isExitButtonVisible;
      _overlayEntry?.markNeedsBuild();  // Rebuild overlay when the exit button state changes
    });
  }

  void _showCard() {
    setState(() {
      _isExitButtonVisible = false;  
    });
    animationCount = 0;
    _showFullscreenVideoCard();
    _audioPlayer.play(AssetSource('frame0/lightconeSound.mp3'));
    Future.delayed(const Duration(milliseconds: 200), () {
     _overlayEntry?.remove();  // Remove the old overlay after the delay
      _overlayEntry = null;
      if (videoNumber == 0) {
        _controller0.pause();
      } else if (videoNumber == 1) {
        _controller1.pause();
      } else if (videoNumber == 2) {
        _controller2.pause();
      }
    });
  }


  void _exitOverlay() {
    _overlayEntryCard?.remove();
    _overlayEntryCard = null;
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    _controllerCard.pause();
    _showMouse();
    setState(() {
      _isExitButtonVisible = false;
    });
  }


  Student _returnCard(numImg) {
    return students[numImg];
  }


  @override
  void dispose() {
    if (videoNumber == 0) {
          _controller0.dispose();
        } else if (videoNumber == 1) {
          _controller1.dispose();
        } else if (videoNumber == 2) {
          _controller2.dispose();
        }
    _animationController.dispose();
    _audioPlayer.dispose();
    _overlayEntry?.remove();
    _overlayEntryCard?.remove();
    _mouseTimer?.cancel();
    super.dispose();
  }
}
